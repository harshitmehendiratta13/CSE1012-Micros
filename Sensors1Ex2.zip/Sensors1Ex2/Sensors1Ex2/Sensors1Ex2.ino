// TMP36 on A1 (GP27), LED on GP15 (pin 15)
int analogPin = A1;
int ledPin    = 15;

// Threshold: LED turns on above this temperature (°C)
// Normal room temp ~22C, "warm" set to 30C
// During testing: normal ~22-24C, hot (under lamp) ~35-55C
float warmThreshold = 30.0;

void setup() {
  Serial.begin(9600);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  int aRead = analogRead(analogPin);
  float vout = aRead * 3.3 / 1023.0;
  float tempC = (vout - 0.5) * 100.0;

  // Print temperature once per second
  Serial.println(tempC, 2);

  // Turn LED on when warm, off when normal
  if (tempC >= warmThreshold) {
    digitalWrite(ledPin, HIGH);  // "warm" range: ~30-55C under heat lamp
  } else {
    digitalWrite(ledPin, LOW);   // "normal" range: ~22-24C room temp
  }

  delay(1000);
}